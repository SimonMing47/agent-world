from PIL import Image
import json
from pathlib import Path

ROOT = Path("agentworld_pixelkit_v0_1")
meta = json.load(open(ROOT / "metadata" / "agentworld_traits.json", encoding="utf-8"))
traits = {(t["layer"], t["id"]): t for t in meta["traits"]}
layer_order = sorted(meta["layer_definitions"], key=lambda x: x["z_index"])

def render_agent(recipe, out_path):
    w, h = meta["canvas"]["w"], meta["canvas"]["h"]
    canvas = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for layer in layer_order:
        layer_id = layer["id"]
        trait_id = recipe.get(layer_id)
        if not trait_id:
            continue
        trait = traits.get((layer_id, trait_id))
        if not trait:
            continue
        part = Image.open(ROOT / trait["file"]).convert("RGBA")
        canvas.alpha_composite(part, (0, 0))
    canvas.save(out_path)

examples = json.load(open(ROOT / "metadata" / "example_agents.json", encoding="utf-8"))
render_agent(examples[0]["recipe"], "rendered_agent.png")
