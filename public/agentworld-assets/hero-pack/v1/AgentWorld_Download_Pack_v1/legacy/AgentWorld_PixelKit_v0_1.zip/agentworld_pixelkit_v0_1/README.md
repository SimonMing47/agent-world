# AgentWorld Pixel Modular Agent Kit v0.1

这是一个用于 AgentWorld 的模块化像素角色素材包。每个部件都是 **96×96 透明 PNG**，统一锚点 `(0,0)`，可按 `z_index` 叠层组合，类似 NFT trait 系统。

## 1. 关键视觉要素

- `base_body`：基础人体、皮肤、手、腿。
- `face`：表情、眼睛、眉毛、嘴；决定 Agent 的性格第一印象。
- `hair`：发型与发色。
- `headgear`：帽子、头盔、眼镜、护目镜、头环。
- `outfit`：职业服装，是角色类别识别的核心。
- `shoes`：靴子/护胫/凉鞋等，强化行动方式。
- `back`：背包、披风、机械包、翅膀、卷轴筒等。
- `hand_item`：火炬、罗盘、书、剑、扳手、药剂、电脑、鲁特琴等。
- `side_prop`：火炬台、终端、盆栽、木箱、符文基座、信标等周边装饰。
- `aura`：火星、星光、护盾、电弧、心形、音符、数据轨道等氛围层。
- `pet`：小宠物或副手，增强 Agent 的辨识度。

## 2. 图层顺序

按以下顺序合成：

`shadow → side_prop → aura → back → base_body → shoes → outfit → face → hair → headgear → hand_item → pet`

## 3. 文件结构

```text
parts/<layer>/<trait_id>.png             # 单个透明部件
spritesheets/<layer>.png                 # 每层未标注精灵表
spritesheets_labelled/<layer>_labelled.png # 带标签预览精灵表
previews/example_agents_12.png           # 12 个示例 Agent 预览
previews/all_parts_overview.png          # 全部部件总览
metadata/agentworld_traits.json          # 主元数据
metadata/traits_flat.csv                 # 扁平 trait 表
metadata/example_agents.json             # 12 个示例配方
metadata/roles.json                      # 角色类别与行为特质
```

## 4. 角色类别

共 12 个角色类别：

- `explorer`：探险侦察者 — 高好奇、高移动、偏风险承受，适合地图探索、信息采样、先行试探。
- `scholar`：学者记录员 — 高分析、高记忆、低冲动，适合资料检索、写作、知识组织。
- `guardian`：守护战士 — 高责任、高抗压、低风险偏移，适合安全边界、审查、保护任务。
- `alchemist`：炼金研究员 — 高创造、高探索、容错式试验，适合原型构建、假设实验、工具组合。
- `engineer`：机械工程师 — 高执行、高修复、高工具亲和，适合代码、工作流、自动化和系统拼装。
- `merchant`：商旅协调者 — 高社交、高权衡、偏协商，适合资源分配、撮合、报价与谈判。
- `healer`：治疗支持者 — 高同理、高稳定、低攻击性，适合用户支持、安抚、复盘与关怀型流程。
- `hacker`：赛博黑客 — 高分析、高自主、高隐蔽，适合调试、异常检测、数据管道和快速检索。
- `farmer`：农夫采集者 — 高耐心、高积累、偏长期主义，适合数据收集、养成、资源维护。
- `pilot`：导航飞行员 — 高方向感、高速度、偏计划，适合任务路由、调度、路径规划。
- `bard`：吟游叙事者 — 高表达、高创造、高社交，适合内容创作、故事、品牌语气与用户互动。
- `oracle`：神谕外交官 — 高抽象、高洞察、高叙事秩序，适合战略建议、长期记忆和跨 Agent 调停。

## 5. 合成建议

1. 先根据 Agent 的行为特质选择 `role`。
2. 从 `role.default_recipe` 获得基础视觉模板。
3. 再根据 `compatibility_rules.agent_trait_to_visual_mapping`，用 Agent 的 `analysis / creativity / empathy / risk_tolerance / autonomy / collaboration / memory_depth / curiosity` 调整部件权重。
4. 按 `z_index` 叠加 PNG，输出角色图。
5. 建议导出时使用 nearest-neighbor 放大 2x、3x 或 4x，保持清晰像素边缘。

## 6. 计数

- 视觉 trait 数：129
- 图层数：12
- 示例 Agent 数：12
